module com.example.levelup {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.net.http;
    requires com.google.gson;


    opens com.example.levelup to javafx.fxml;
    exports com.example.levelup;
}