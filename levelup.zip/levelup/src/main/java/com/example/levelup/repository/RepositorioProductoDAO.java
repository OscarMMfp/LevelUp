package com.example.levelup.repository;

import com.example.levelup.database.ConexionBD;
import com.example.levelup.model.Producto;
import com.example.levelup.model.ProductoMasVendido;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RepositorioProductoDAO
        implements RepositorioDAO<Producto, Integer> {

    @Override
    public boolean add(Producto data) {

        String sql = """
                INSERT INTO producto
                (nombre, descripcion, precio, stock,
                 tamanio, color, idCategoria, idProveedor)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setString(1, data.getNombre());
            ps.setString(2, data.getDescripcion());
            ps.setFloat(3, data.getPrecio());
            ps.setInt(4, data.getStock());
            ps.setString(5, data.getTamanio());
            ps.setString(6, data.getColor());
            ps.setInt(7, data.getIdCategoria());
            ps.setInt(8, data.getIdProveedor());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public boolean remove(Integer id) {

        String sql =
                "DELETE FROM producto WHERE id = ?";

        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public Producto findById(Integer id) {

        String sql =
                "SELECT * FROM producto WHERE id = ?";

        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Producto producto = new Producto();

                producto.setId(rs.getInt("id"));
                producto.setNombre(rs.getString("nombre"));
                producto.setDescripcion(
                        rs.getString("descripcion"));
                producto.setPrecio(rs.getFloat("precio"));
                producto.setStock(rs.getInt("stock"));
                producto.setTamanio(rs.getString("tamanio"));
                producto.setColor(rs.getString("color"));
                producto.setIdCategoria(
                        rs.getInt("idCategoria"));
                producto.setIdProveedor(
                        rs.getInt("idProveedor"));

                return producto;
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean update(Producto data) {
        String sql = """
                UPDATE producto
                SET nombre = ?,
                    descripcion = ?,
                    precio = ?,
                    stock = ?,
                    tamanio = ?,
                    color = ?,
                    idCategoria = ?,
                    idProveedor = ?
                WHERE id = ?
                """;
        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setString(1, data.getNombre());
            ps.setString(2, data.getDescripcion());
            ps.setFloat(3, data.getPrecio());
            ps.setInt(4, data.getStock());
            ps.setString(5, data.getTamanio());
            ps.setString(6, data.getColor());
            ps.setInt(7, data.getIdCategoria());
            ps.setInt(8, data.getIdProveedor());
            ps.setInt(9, data.getId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public List<Producto> getList() {

        String sql = "SELECT * FROM producto";

        List<Producto> productos = new ArrayList<>();

        try (
                Statement st =
                        ConexionBD.getConexion().createStatement();

                ResultSet rs = st.executeQuery(sql)
        ) {

            while (rs.next()) {

                Producto producto = new Producto();

                producto.setId(rs.getInt("id"));
                producto.setNombre(rs.getString("nombre"));
                producto.setDescripcion(
                        rs.getString("descripcion"));
                producto.setPrecio(rs.getFloat("precio"));
                producto.setStock(rs.getInt("stock"));
                producto.setTamanio(rs.getString("tamanio"));
                producto.setColor(rs.getString("color"));
                producto.setIdCategoria(
                        rs.getInt("idCategoria"));
                producto.setIdProveedor(
                        rs.getInt("idProveedor"));

                productos.add(producto);
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }

        return productos;
    }
    public List<ProductoMasVendido> getProductosMasVendidos() {

        String sql = """
            SELECT
                p.nombre,
                SUM(d.cantidad) AS unidadesVendidas
            FROM producto p
            JOIN detalle d
            ON p.id = d.idProducto
            GROUP BY p.id
            ORDER BY unidadesVendidas DESC
            LIMIT 10
            """;

        List<ProductoMasVendido> lista =
                new ArrayList<>();

        try (
                Statement st =
                        ConexionBD.getConexion().createStatement();

                ResultSet rs = st.executeQuery(sql)
        ) {

            while (rs.next()) {

                ProductoMasVendido p =
                        new ProductoMasVendido();

                p.setNombre(rs.getString("nombre"));

                p.setUnidadesVendidas(
                        rs.getInt("unidadesVendidas")
                );

                lista.add(p);
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }

        return lista;
    }
    public List<Producto> getProductosBajoStock() {

        String sql = """
            SELECT *
            FROM producto
            WHERE stock < 20
            ORDER BY stock ASC
            """;

        List<Producto> lista =
                new ArrayList<>();

        try (
                Statement st =
                        ConexionBD.getConexion().createStatement();

                ResultSet rs = st.executeQuery(sql)
        ) {

            while (rs.next()) {

                Producto p = new Producto();

                p.setId(rs.getInt("id"));
                p.setNombre(rs.getString("nombre"));
                p.setStock(rs.getInt("stock"));
                p.setPrecio(rs.getFloat("precio"));

                lista.add(p);
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }

        return lista;
    }
}