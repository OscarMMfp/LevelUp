package com.example.levelup;

import com.example.levelup.model.*;
import com.example.levelup.repository.RepositorioCategoriaDAO;
import com.example.levelup.repository.RepositorioClienteDAO;

import com.example.levelup.repository.RepositorioProductoDAO;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.layout.VBox;
import com.example.levelup.service.LlmService;

import java.util.List;

public class HelloController {
    @FXML
    private VBox panelCatalogo;
    @FXML
    private VBox panelEdicion;
    @FXML
    private VBox panelResumenCategoria;
    @FXML
    private VBox panelListadoClientes;
    @FXML
    private VBox panelResumenFacturacionCliente;
    @FXML
    private TableView<Cliente> tablaClientes;
    @FXML
    private TableColumn<Cliente, String> colDni;
    @FXML
    private TableColumn<Cliente, String> colNombre;
    @FXML
    private TableColumn<Cliente, String> colApellido;
    @FXML
    private TableColumn<Cliente, String> colEmail;
    @FXML
    private TableColumn<Cliente, String> colCiudad;
    @FXML
    private TableColumn<Cliente, String> colTelefono;
    private final RepositorioClienteDAO repositorioClienteDAO =
            new RepositorioClienteDAO();
    @FXML
    public void initialize() {

        ocultarPaneles();
        panelCatalogo.setVisible(true);
        configurarTabla();
        cargarClientes();
        configurarTablaFacturacion();
        cargarFacturacionClientes();
        configurarTablaProductosMasVendidos();
        configurarTablaFacturacionCategoria();
        configurarTablaBajoStock();
        configurarTablaProductos();
        cargarProductos();
        configurarTablaResumenCategoria();
        cargarListaProductosEdicion();
    }
    @FXML
    private TableView<ResumenFacturacionCliente>
            tablaFacturacionCliente;
    @FXML
    private TableColumn<
            ResumenFacturacionCliente,
            String> colNombreCliente;
    @FXML
    private TableColumn<
            ResumenFacturacionCliente,
            String> colApellidoCliente;
    @FXML
    private TableColumn<
            ResumenFacturacionCliente,
            Float> colTotalFacturado;
    @FXML
    private VBox panelProductosMasVendidos;
    @FXML
    private TableView<ProductoMasVendido>
            tablaProductosMasVendidos;
    @FXML
    private TableColumn<
            ProductoMasVendido,
            String> colProductoVendido;
    @FXML
    private TableColumn<
            ProductoMasVendido,
            Integer> colUnidadesVendidas;
    @FXML
    private VBox panelFacturacionCategoria;
    @FXML
    private TableView<ResumenCategoria>
            tablaFacturacionCategoria;
    @FXML
    private TableColumn<
            ResumenCategoria,
            String> colCategoria;
    @FXML
    private TableColumn<
            ResumenCategoria,
            Float> colTotalCategoria;
    @FXML
    private VBox panelProductosBajoStock;
    @FXML
    private TableView<Producto>
            tablaProductosBajoStock;
    @FXML
    private TableColumn<
            Producto,
            String> colNombreStock;
    @FXML
    private TableColumn<
            Producto,
            Integer> colStock;
    @FXML
    private TableColumn<
            Producto,
            Float> colPrecioStock;
    @FXML
    private TableView<Producto> tablaProductos;
    @FXML
    private TableColumn<Producto, String> colNombreP;
    @FXML
    private TableColumn<Producto, String> colDescripcion;
    @FXML
    private TableColumn<Producto, Float> colPrecio;
    @FXML
    private TableColumn<Producto, Integer> colStockP;
    @FXML
    private TableColumn<Producto, String> colTamanio;
    @FXML
    private TableColumn<Producto, String> colColor;
    @FXML
    private TableView<ProductoCategoria>
            tablaResumenCategoria;
    @FXML
    private TableColumn<
            ProductoCategoria,
            String> colCategoriaResumen;
    @FXML
    private TableColumn<
            ProductoCategoria,
            String> colProductoCategoria;
    @FXML
    private TableColumn<
            ProductoCategoria,
            Integer> colStockCategoria;
    @FXML
    private TableColumn<
            ProductoCategoria,
            Float> colPrecioCategoria;
    @FXML
    private TextField txtIdProducto;
    @FXML
    private TextField txtNombreProducto;
    @FXML
    private TextField txtDescripcionProducto;
    @FXML
    private TextField txtPrecioProducto;
    @FXML
    private TextField txtStockProducto;
    @FXML
    private TextField txtTamanioProducto;
    @FXML
    private TextField txtColorProducto;
    @FXML
    private TextField txtIdCategoria;
    @FXML
    private TextField txtIdProveedor;
    @FXML
    private TextField txtTipoIA;
    @FXML
    private TextField txtFranquiciaIA;
    private final LlmService llmService =
            new LlmService();
    private void configurarTabla() {
        colDni.setCellValueFactory(
                data -> new javafx.beans.property.SimpleStringProperty(
                        data.getValue().getDni()
                )
        );
        colNombre.setCellValueFactory(
                data -> new javafx.beans.property.SimpleStringProperty(
                        data.getValue().getNombre()
                )
        );
        colApellido.setCellValueFactory(
                data -> new javafx.beans.property.SimpleStringProperty(
                        data.getValue().getApellido()
                )
        );
        colEmail.setCellValueFactory(
                data -> new javafx.beans.property.SimpleStringProperty(
                        data.getValue().getEmail()
                )
        );
        colCiudad.setCellValueFactory(
                data -> new javafx.beans.property.SimpleStringProperty(
                        data.getValue().getCiudad()
                )
        );
        colTelefono.setCellValueFactory(
                data -> new javafx.beans.property.SimpleStringProperty(
                        data.getValue().getTlf()
                )
        );
    }
    private void cargarClientes() {
        ObservableList<Cliente> listaClientes =
                FXCollections.observableArrayList(
                        repositorioClienteDAO.getList()
                );
        tablaClientes.setItems(listaClientes);
    }
    public void mostrarCatalogo(ActionEvent actionEvent) {
        ocultarPaneles();
        panelCatalogo.setVisible(true);
    }
    public void mostrarEdicion(ActionEvent actionEvent) {
        ocultarPaneles();
        panelEdicion.setVisible(true);
    }
    public void mostrarListadoClientes(ActionEvent actionEvent) {
        ocultarPaneles();
        panelListadoClientes.setVisible(true);
    }
    public void mostrarResumenFacturacionCliente(ActionEvent actionEvent) {
        ocultarPaneles();
        panelResumenFacturacionCliente.setVisible(true);
    }
    private void configurarTablaFacturacion() {
        colNombreCliente.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getNombre()
                )
        );
        colApellidoCliente.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getApellido()
                )
        );
        colTotalFacturado.setCellValueFactory(
                data -> new SimpleObjectProperty<>(
                        data.getValue().getTotalFacturado()
                )
        );
    }
    private void cargarFacturacionClientes() {
        ObservableList<ResumenFacturacionCliente> lista =
                FXCollections.observableArrayList(
                        repositorioClienteDAO
                                .getResumenFacturacion()
                );
        tablaFacturacionCliente.setItems(lista);
    }
    public void mostrarProductosMasVendidos(
            ActionEvent actionEvent
    ) {
        ocultarPaneles();
        panelProductosMasVendidos.setVisible(true);
        panelProductosMasVendidos.setManaged(true);
        cargarProductosMasVendidos();
    }
    public void mostrarFacturacionCategoria(
            ActionEvent actionEvent
    ) {
        ocultarPaneles();
        panelFacturacionCategoria.setVisible(true);
        panelFacturacionCategoria.setManaged(true);
        cargarFacturacionCategoria();
    }
    public void mostrarProductosBajoStock(
            ActionEvent actionEvent
    ) {
        ocultarPaneles();
        panelProductosBajoStock.setVisible(true);
        panelProductosBajoStock.setManaged(true);
        cargarProductosBajoStock();
    }
    public void ocultarPaneles() {
        panelCatalogo.setVisible(false);
        panelEdicion.setVisible(false);
        panelResumenCategoria.setVisible(false);
        panelListadoClientes.setVisible(false);
        panelResumenFacturacionCliente.setVisible(false);
        panelProductosMasVendidos.setVisible(false);
        panelProductosMasVendidos.setManaged(false);
        panelFacturacionCategoria.setVisible(false);
        panelFacturacionCategoria.setManaged(false);
        panelProductosBajoStock.setVisible(false);
        panelProductosBajoStock.setManaged(false);
    }
    private final RepositorioProductoDAO
            repositorioProductoDAO =
            new RepositorioProductoDAO();
    private void configurarTablaProductosMasVendidos() {

        colProductoVendido.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getNombre()
                )
        );
        colUnidadesVendidas.setCellValueFactory(
                data -> new SimpleObjectProperty<>(
                        data.getValue().getUnidadesVendidas()
                )
        );
    }
    private void cargarProductosMasVendidos() {

        ObservableList<ProductoMasVendido> lista =

                FXCollections.observableArrayList(
                        repositorioProductoDAO
                                .getProductosMasVendidos()
                );

        tablaProductosMasVendidos.setItems(lista);
    }
    private final RepositorioCategoriaDAO
            repositorioCategoriaDAO =
            new RepositorioCategoriaDAO();
    private void configurarTablaFacturacionCategoria() {

        colCategoria.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getCategoria()
                )
        );
        colTotalCategoria.setCellValueFactory(
                data -> new SimpleObjectProperty<>(
                        data.getValue().getTotalFacturado()
                )
        );
    }
    private void cargarFacturacionCategoria() {
        ObservableList<ResumenCategoria> lista =
                FXCollections.observableArrayList(
                        repositorioCategoriaDAO
                                .getFacturacionCategoria()
                );
        tablaFacturacionCategoria.setItems(lista);
    }
    private void configurarTablaBajoStock() {
        colNombreStock.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getNombre()
                )
        );
        colStock.setCellValueFactory(
                data -> new SimpleObjectProperty<>(
                        data.getValue().getStock()
                )
        );
        colPrecioStock.setCellValueFactory(
                data -> new SimpleObjectProperty<>(
                        data.getValue().getPrecio()
                )
        );
    }
    private void cargarProductosBajoStock() {
        ObservableList<Producto> lista =

                FXCollections.observableArrayList(
                        repositorioProductoDAO
                                .getProductosBajoStock()
                );
        tablaProductosBajoStock.setItems(lista);
    }
    private void configurarTablaProductos() {
        colNombreP.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getNombre()
                )
        );
        colDescripcion.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getDescripcion()
                )
        );
        colPrecio.setCellValueFactory(
                data -> new SimpleObjectProperty<>(
                        data.getValue().getPrecio()
                )
        );
        colStockP.setCellValueFactory(
                data -> new SimpleObjectProperty<>(
                        data.getValue().getStock()
                )
        );
        colTamanio.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getTamanio()
                )
        );
        colColor.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getColor()
                )
        );
    }
    private void cargarProductos() {
        ObservableList<Producto> lista =
                FXCollections.observableArrayList(
                        repositorioProductoDAO.getList()
                );
        tablaProductos.setItems(lista);
    }
    private void configurarTablaResumenCategoria() {
        colCategoriaResumen.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getCategoria()
                )
        );
        colProductoCategoria.setCellValueFactory(
                data -> new SimpleStringProperty(
                        data.getValue().getProducto()
                )
        );
        colStockCategoria.setCellValueFactory(
                data -> new SimpleObjectProperty<>(
                        data.getValue().getStock()
                )
        );
        colPrecioCategoria.setCellValueFactory(
                data -> new SimpleObjectProperty<>(
                        data.getValue().getPrecio()
                )
        );
    }
    private void cargarResumenCategoria() {

        ObservableList<ProductoCategoria> lista =
                FXCollections.observableArrayList(
                        repositorioCategoriaDAO
                                .getProductosPorCategoria()
                );
        tablaResumenCategoria.setItems(lista);
    }
    public void mostrarResumenCategoria(ActionEvent actionEvent) {
        ocultarPaneles();
        panelResumenCategoria.setVisible(true);
        panelResumenCategoria.setManaged(true);
        cargarResumenCategoria();
    }
    private List<Producto> productos;
    private int posicionActual = 0;
    private void cargarListaProductosEdicion() {
        productos = repositorioProductoDAO.getList();
        if (!productos.isEmpty()) {
            posicionActual = 0;
            mostrarProducto();
        }
    }
    private void mostrarProducto() {
        Producto p = productos.get(posicionActual);
        txtIdProducto.setText(
                String.valueOf(p.getId())
        );
        txtNombreProducto.setText(
                p.getNombre()
        );
        txtDescripcionProducto.setText(
                p.getDescripcion()
        );
        txtPrecioProducto.setText(
                String.valueOf(p.getPrecio())
        );
        txtStockProducto.setText(
                String.valueOf(p.getStock())
        );
        txtTamanioProducto.setText(
                p.getTamanio()
        );
        txtColorProducto.setText(
                p.getColor()
        );
        txtIdCategoria.setText(
                String.valueOf(p.getIdCategoria())
        );
        txtIdProveedor.setText(
                String.valueOf(p.getIdProveedor())
        );
    }
    public void primeroProducto(ActionEvent e) {
        if (!productos.isEmpty()) {
            posicionActual = 0;
            mostrarProducto();
        }
    }
    public void anteriorProducto(ActionEvent e) {
        if (posicionActual > 0) {
            posicionActual--;
            mostrarProducto();
        }
    }
    public void siguienteProducto(ActionEvent e) {
        if (posicionActual < productos.size() - 1) {
            posicionActual++;
            mostrarProducto();
        }
    }
    public void ultimoProducto(ActionEvent e) {
        if (!productos.isEmpty()) {
            posicionActual = productos.size() - 1;
            mostrarProducto();
        }
    }
    public void nuevoProducto(ActionEvent e) {
        txtIdProducto.clear();
        txtNombreProducto.clear();
        txtDescripcionProducto.clear();
        txtPrecioProducto.clear();
        txtStockProducto.clear();
        txtTamanioProducto.clear();
        txtColorProducto.clear();
    }
    public void guardarProducto(ActionEvent e) {
        Producto p = new Producto();
        p.setNombre(
                txtNombreProducto.getText()
        );
        p.setDescripcion(
                txtDescripcionProducto.getText()
        );
        p.setPrecio(
                Float.parseFloat(
                        txtPrecioProducto.getText()
                )
        );
        p.setStock(
                Integer.parseInt(
                        txtStockProducto.getText()
                )
        );
        p.setTamanio(
                txtTamanioProducto.getText()
        );
        p.setColor(
                txtColorProducto.getText()
        );
        p.setIdCategoria(
                Integer.parseInt(
                        txtIdCategoria.getText()
                )
        );
        p.setIdProveedor(
                Integer.parseInt(
                        txtIdProveedor.getText()
                )
        );
        repositorioProductoDAO.add(p);
        cargarListaProductosEdicion();
    }
    public void eliminarProducto(ActionEvent e) {
        int id = Integer.parseInt(
                txtIdProducto.getText()
        );
        repositorioProductoDAO.remove(id);
        cargarListaProductosEdicion();
    }
    public void actualizarProducto(ActionEvent e) {
        Producto p = new Producto();
        p.setId(
                Integer.parseInt(
                        txtIdProducto.getText()
                )
        );
        p.setNombre(
                txtNombreProducto.getText()
        );
        p.setDescripcion(
                txtDescripcionProducto.getText()
        );
        p.setPrecio(
                Float.parseFloat(
                        txtPrecioProducto.getText()
                )
        );
        p.setStock(
                Integer.parseInt(
                        txtStockProducto.getText()
                )
        );
        p.setTamanio(
                txtTamanioProducto.getText()
        );
        p.setColor(
                txtColorProducto.getText()
        );
        p.setIdCategoria(
                Integer.parseInt(
                        txtIdCategoria.getText()
                )
        );
        p.setIdProveedor(
                Integer.parseInt(
                        txtIdProveedor.getText()
                )
        );
        repositorioProductoDAO.update(p);
        cargarProductos();
        cargarListaProductosEdicion();
    }
    public void generarNombreIA(ActionEvent e) {
        String tipo =
                txtTipoIA.getText();
        String franquicia =
                txtFranquiciaIA.getText();
        String nombreGenerado =
                llmService.sugerirNombreProducto(
                        tipo,
                        franquicia
                );
        txtNombreProducto.setText(
                nombreGenerado
        );
    }
}