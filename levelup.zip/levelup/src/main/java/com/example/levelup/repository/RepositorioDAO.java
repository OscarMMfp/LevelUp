package com.example.levelup.repository;

import java.util.List;
public interface RepositorioDAO<TipoRegistro, TipoId> {
    boolean add(TipoRegistro data);
    boolean remove(TipoId id);
    TipoRegistro findById(TipoId id);
    boolean update(TipoRegistro data);
    List<TipoRegistro> getList();
}