package com.example.levelup.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Properties;

public class LlmService {

    private String apiKey;

    public LlmService() {

        try {

            Properties props = new Properties();
            InputStream input =
                    new FileInputStream(
                            "C:\\levelupConfig\\config.properties"
                    );

            props.load(input);

            apiKey =
                    props.getProperty(
                            "OPENROUTER_API_KEY"
                    );

        } catch (Exception e) {

            System.out.println(
                    "Error leyendo config.properties"
            );

            e.printStackTrace();
        }
    }

    public String sugerirNombreProducto(
            String tipo,
            String franquicia
    ) {

        String prompt =
                "Sugiere un nombre llamativo y original "
                        + "para un producto otaku del tipo '"
                        + tipo
                        + "' basado en la franquicia '"
                        + franquicia
                        + "'. Solo devuelve el nombre.";

        try {

            HttpClient client =
                    HttpClient.newHttpClient();

            JsonObject message =
                    new JsonObject();

            message.addProperty(
                    "role",
                    "user"
            );

            message.addProperty(
                    "content",
                    prompt
            );

            JsonArray messages =
                    new JsonArray();

            messages.add(message);

            JsonObject body =
                    new JsonObject();

            // MODELO GRATUITO FUNCIONAL
            body.addProperty("model", "openrouter/free");
            body.add(
                    "messages",
                    messages
            );

            HttpRequest request =
                    HttpRequest.newBuilder()

                            .uri(
                                    new URI(
                                            "https://openrouter.ai/api/v1/chat/completions"
                                    )
                            )

                            .header(
                                    "Authorization",
                                    "Bearer " + apiKey
                            )

                            .header(
                                    "Content-Type",
                                    "application/json"
                            )

                            .header(
                                    "HTTP-Referer",
                                    "http://localhost"
                            )

                            .header(
                                    "X-Title",
                                    "LevelUp"
                            )

                            .POST(
                                    HttpRequest
                                            .BodyPublishers
                                            .ofString(body.toString())
                            )

                            .build();

            HttpResponse<String> response =

                    client.send(
                            request,
                            HttpResponse
                                    .BodyHandlers
                                    .ofString()
                    );

            // DEBUG
            System.out.println("CODIGO HTTP:");
            System.out.println(response.statusCode());

            System.out.println("RESPUESTA:");
            System.out.println(response.body());

            JsonObject json =
                    JsonParser
                            .parseString(response.body())
                            .getAsJsonObject();

            // SI OPENROUTER DEVUELVE ERROR
            if (!json.has("choices")) {

                return "ERROR OPENROUTER:\n"
                        + response.body();
            }

            // RESPUESTA CORRECTA
            return json

                    .getAsJsonArray("choices")
                    .get(0)
                    .getAsJsonObject()
                    .getAsJsonObject("message")
                    .get("content")
                    .getAsString();

        } catch (Exception e) {

            e.printStackTrace();

            return "ERROR:\n" + e.getMessage();
        }
    }
}