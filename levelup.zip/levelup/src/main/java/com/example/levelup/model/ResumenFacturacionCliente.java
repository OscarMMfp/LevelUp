package com.example.levelup.model;

public class ResumenFacturacionCliente {
    private String nombre;
    private String apellido;
    private float totalFacturado;
    public ResumenFacturacionCliente() {
    }
    public ResumenFacturacionCliente(
            String nombre,
            String apellido,
            float totalFacturado
    ) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.totalFacturado = totalFacturado;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public float getTotalFacturado() {
        return totalFacturado;
    }
    public void setTotalFacturado(float totalFacturado) {
        this.totalFacturado = totalFacturado;
    }
}