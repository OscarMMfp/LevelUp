package com.example.levelup.repository;

import com.example.levelup.database.ConexionBD;
import com.example.levelup.model.Cliente;
import com.example.levelup.model.ResumenFacturacionCliente;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RepositorioClienteDAO
        implements RepositorioDAO<Cliente, String> {

    @Override
    public boolean add(Cliente data) {

        String sql = """
                INSERT INTO cliente
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setString(1, data.getDni());
            ps.setString(2, data.getNombre());
            ps.setString(3, data.getApellido());

            if (data.getFechaNacimiento() != null) {
                ps.setDate(4,
                        Date.valueOf(data.getFechaNacimiento()));
            } else {
                ps.setNull(4, Types.DATE);
            }

            ps.setString(5, data.getEmail());
            ps.setString(6, data.getDireccion());
            ps.setString(7, data.getCiudad());
            ps.setString(8, data.getCp());
            ps.setString(9, data.getTlf());

            if (data.getFechaRegistro() != null) {
                ps.setDate(10,
                        Date.valueOf(data.getFechaRegistro()));
            } else {
                ps.setNull(10, Types.DATE);
            }

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public boolean remove(String dni) {

        String sql = "DELETE FROM cliente WHERE dni = ?";

        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setString(1, dni);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public Cliente findById(String dni) {

        String sql = "SELECT * FROM cliente WHERE dni = ?";

        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setString(1, dni);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Cliente cliente = new Cliente();

                cliente.setDni(rs.getString("dni"));
                cliente.setNombre(rs.getString("nombre"));
                cliente.setApellido(rs.getString("apellido"));

                Date fechaNacimiento =
                        rs.getDate("fechaNacimiento");

                if (fechaNacimiento != null) {
                    cliente.setFechaNacimiento(
                            fechaNacimiento.toLocalDate()
                    );
                }

                cliente.setEmail(rs.getString("email"));
                cliente.setDireccion(rs.getString("direccion"));
                cliente.setCiudad(rs.getString("ciudad"));
                cliente.setCp(rs.getString("cp"));
                cliente.setTlf(rs.getString("tlf"));

                Date fechaRegistro =
                        rs.getDate("fechaRegistro");

                if (fechaRegistro != null) {
                    cliente.setFechaRegistro(
                            fechaRegistro.toLocalDate()
                    );
                }

                return cliente;
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean update(Cliente data) {

        String sql = """
                UPDATE cliente
                SET nombre = ?,
                    apellido = ?,
                    fechaNacimiento = ?,
                    email = ?,
                    direccion = ?,
                    ciudad = ?,
                    cp = ?,
                    tlf = ?,
                    fechaRegistro = ?
                WHERE dni = ?
                """;

        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setString(1, data.getNombre());
            ps.setString(2, data.getApellido());

            if (data.getFechaNacimiento() != null) {
                ps.setDate(3,
                        Date.valueOf(data.getFechaNacimiento()));
            } else {
                ps.setNull(3, Types.DATE);
            }

            ps.setString(4, data.getEmail());
            ps.setString(5, data.getDireccion());
            ps.setString(6, data.getCiudad());
            ps.setString(7, data.getCp());
            ps.setString(8, data.getTlf());

            if (data.getFechaRegistro() != null) {
                ps.setDate(9,
                        Date.valueOf(data.getFechaRegistro()));
            } else {
                ps.setNull(9, Types.DATE);
            }

            ps.setString(10, data.getDni());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public List<Cliente> getList() {

        String sql = "SELECT * FROM cliente";

        List<Cliente> clientes = new ArrayList<>();

        try (
                Statement st =
                        ConexionBD.getConexion().createStatement();

                ResultSet rs = st.executeQuery(sql)
        ) {

            while (rs.next()) {

                Cliente cliente = new Cliente();

                cliente.setDni(rs.getString("dni"));
                cliente.setNombre(rs.getString("nombre"));
                cliente.setApellido(rs.getString("apellido"));

                Date fechaNacimiento =
                        rs.getDate("fechaNacimiento");

                if (fechaNacimiento != null) {

                    cliente.setFechaNacimiento(
                            fechaNacimiento.toLocalDate()
                    );
                }

                cliente.setEmail(rs.getString("email"));
                cliente.setDireccion(rs.getString("direccion"));
                cliente.setCiudad(rs.getString("ciudad"));
                cliente.setCp(rs.getString("cp"));
                cliente.setTlf(rs.getString("tlf"));

                Date fechaRegistro =
                        rs.getDate("fechaRegistro");

                if (fechaRegistro != null) {

                    cliente.setFechaRegistro(
                            fechaRegistro.toLocalDate()
                    );
                }

                clientes.add(cliente);

                System.out.println(cliente);
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }

        return clientes;
    }

    public List<ResumenFacturacionCliente>
    getResumenFacturacion() {

        String sql = " SELECT c.nombre, c.apellido, SUM(p.total) AS totalFacturado FROM cliente c JOIN pedido p ON c.dni = p.idCliente GROUP BY c.dni ORDER BY totalFacturado DESC";
        List<ResumenFacturacionCliente> lista =
                new ArrayList<>();
        try (
                Statement st =
                        ConexionBD.getConexion().createStatement();
                ResultSet rs = st.executeQuery(sql)
        ) {
            while (rs.next()) {
                ResumenFacturacionCliente r =
                        new ResumenFacturacionCliente();
                r.setNombre(rs.getString("nombre"));
                r.setApellido(rs.getString("apellido"));
                r.setTotalFacturado(
                        rs.getFloat("totalFacturado")
                );
                lista.add(r);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return lista;
    }
}
