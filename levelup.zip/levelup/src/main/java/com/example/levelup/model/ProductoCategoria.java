package com.example.levelup.model;

public class ProductoCategoria {

    private String categoria;
    private String producto;
    private int stock;
    private float precio;

    public ProductoCategoria() {
    }

    public ProductoCategoria(
            String categoria,
            String producto,
            int stock,
            float precio
    ) {
        this.categoria = categoria;
        this.producto = producto;
        this.stock = stock;
        this.precio = precio;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }
}