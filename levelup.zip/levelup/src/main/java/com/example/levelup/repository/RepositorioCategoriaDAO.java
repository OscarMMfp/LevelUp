package com.example.levelup.repository;

import com.example.levelup.database.ConexionBD;
import com.example.levelup.model.Categoria;
import com.example.levelup.model.ProductoCategoria;
import com.example.levelup.model.ResumenCategoria;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RepositorioCategoriaDAO
        implements RepositorioDAO<Categoria, Integer> {

    @Override
    public boolean add(Categoria data) {

        String sql =
                "INSERT INTO categoria(nombre, descripcion) VALUES (?, ?)";

        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setString(1, data.getNombre());
            ps.setString(2, data.getDescripcion());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public boolean remove(Integer id) {

        String sql =
                "DELETE FROM categoria WHERE id = ?";

        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public Categoria findById(Integer id) {

        String sql =
                "SELECT * FROM categoria WHERE id = ?";

        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Categoria categoria = new Categoria();

                categoria.setId(rs.getInt("id"));
                categoria.setNombre(rs.getString("nombre"));
                categoria.setDescripcion(
                        rs.getString("descripcion"));

                return categoria;
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean update(Categoria data) {

        String sql = """
                UPDATE categoria
                SET nombre = ?, descripcion = ?
                WHERE id = ?
                """;

        try (PreparedStatement ps =
                     ConexionBD.getConexion().prepareStatement(sql)) {

            ps.setString(1, data.getNombre());
            ps.setString(2, data.getDescripcion());
            ps.setInt(3, data.getId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public List<Categoria> getList() {

        String sql = "SELECT * FROM categoria";

        List<Categoria> categorias = new ArrayList<>();

        try (
                Statement st =
                        ConexionBD.getConexion().createStatement();

                ResultSet rs = st.executeQuery(sql)
        ) {

            while (rs.next()) {

                Categoria categoria = new Categoria();

                categoria.setId(rs.getInt("id"));
                categoria.setNombre(rs.getString("nombre"));
                categoria.setDescripcion(
                        rs.getString("descripcion"));

                categorias.add(categoria);
            }

        } catch (SQLException e) {

            System.out.println(e.getMessage());
        }

        return categorias;
    }
    public List<ResumenCategoria> getFacturacionCategoria() {
        String sql = """
            SELECT
                c.nombre,
                SUM(d.subtotal) AS totalFacturado
            FROM categoria c
            JOIN producto p
            ON c.id = p.idCategoria
            JOIN detalle d
            ON p.id = d.idProducto
            GROUP BY c.id
            ORDER BY totalFacturado DESC
            """;
        List<ResumenCategoria> lista =
                new ArrayList<>();
        try (
                Statement st =
                        ConexionBD.getConexion().createStatement();
                ResultSet rs = st.executeQuery(sql)
        ) {
            while (rs.next()) {
                ResumenCategoria r =
                        new ResumenCategoria();
                r.setCategoria(rs.getString("nombre"));
                r.setTotalFacturado(
                        rs.getFloat("totalFacturado")
                );
                lista.add(r);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return lista;
    }
    public List<ProductoCategoria>
    getProductosPorCategoria() {
        String sql = """
            SELECT
                c.nombre AS categoria,
                p.nombre AS producto,
                p.stock,
                p.precio
            FROM categoria c
            JOIN producto p
            ON c.id = p.idCategoria
            ORDER BY c.nombre, p.nombre
            """;
        List<ProductoCategoria> lista =
                new ArrayList<>();
        try (
                Statement st =
                        ConexionBD.getConexion()
                                .createStatement();
                ResultSet rs =
                        st.executeQuery(sql)

        ) {
            while (rs.next()) {
                ProductoCategoria p =
                        new ProductoCategoria();
                p.setCategoria(
                        rs.getString("categoria")
                );
                p.setProducto(
                        rs.getString("producto")
                );
                p.setStock(
                        rs.getInt("stock")
                );
                p.setPrecio(
                        rs.getFloat("precio")
                );
                lista.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return lista;
    }
}