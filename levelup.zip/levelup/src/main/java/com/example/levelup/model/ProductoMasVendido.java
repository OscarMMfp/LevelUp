package com.example.levelup.model;

public class ProductoMasVendido {

    private String nombre;
    private int unidadesVendidas;

    public ProductoMasVendido() {
    }

    public ProductoMasVendido(
            String nombre,
            int unidadesVendidas
    ) {
        this.nombre = nombre;
        this.unidadesVendidas = unidadesVendidas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getUnidadesVendidas() {
        return unidadesVendidas;
    }

    public void setUnidadesVendidas(int unidadesVendidas) {
        this.unidadesVendidas = unidadesVendidas;
    }
}