package com.example.levelup.model;

public class ResumenCategoria {

    private String categoria;
    private float totalFacturado;

    public ResumenCategoria() {
    }

    public ResumenCategoria(
            String categoria,
            float totalFacturado
    ) {
        this.categoria = categoria;
        this.totalFacturado = totalFacturado;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public float getTotalFacturado() {
        return totalFacturado;
    }

    public void setTotalFacturado(float totalFacturado) {
        this.totalFacturado = totalFacturado;
    }
}